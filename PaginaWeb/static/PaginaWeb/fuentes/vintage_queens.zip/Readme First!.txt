Hi There,
Thank for downloading my font.




NOTE: 
This font is for PERSONAL USE ONLY !(NOT FOR COMMERCIAL). 
But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/putracetol


Link to purchase full version and commercial license: 
https://creativemarket.com/putracetol?u=putracetol

Please visit our store for more great fonts : 
https://creativemarket.com/putracetol?u=putracetol

If there is a problem, question, or anything about my fonts, please sent an email to putra.designer@gmail.com

Thanks,

PutraCetol Studio

INDONESIA : 

Halo, 
Buat agency, designer, youtuber, atau siapa saja yang ingin menggunakan font ini untuk kebutuhan KOMERSIL seperti poster film, pamflet promo, logo perusahaan, kaos, dan sejenisnya bisa langsung membeli lisensinya di saya, silahkan hubungi saya melalui :

email : putra.designer@gmail.com 

Terima kasih,
PutraCetol Studio